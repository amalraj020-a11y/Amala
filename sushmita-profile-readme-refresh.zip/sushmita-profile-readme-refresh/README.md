<!--
  Burgundy profile README refresh for Sri Sushmita Dasari.
  Identity-sensitive claims are intentionally omitted until a matching resume/repository is supplied.
  Phone number intentionally omitted.
-->

<p align="center">
  <img src="assets/sushmita-hero.svg" alt="Sri Sushmita Dasari — AI/ML Engineer, Full-Stack Developer, Creative Technologist" width="100%" />
</p>

<p align="center">
  <strong>Building intelligent systems and thoughtful digital experiences.</strong><br />
  AI/ML Engineering&nbsp; · &nbsp;Full-Stack Development&nbsp; · &nbsp;Creative Technology
</p>

<p align="center">
  <!-- Add verified profile URLs here once the correct GitHub identity is confirmed. -->
  <em>Professional links will be added after the existing profile repository is inspected.</em>
</p>

---

## About

I'm **Sri Sushmita Dasari**, positioning my work at the intersection of **AI/ML engineering, full-stack development, and creative technology**. I value clear engineering, useful products, and interfaces that make complex ideas feel approachable.

> Education, credentials, and project details are intentionally not asserted here until they can be checked against a resume and the existing repositories.

## Selected Work

This section is reserved for real projects with working repository or demo links. Add only projects that can be verified from the supplied source repository or profile.

## Technical Focus

- **AI & Machine Learning** — AI/ML engineering
- **Application Engineering** — Full-stack development
- **Product & Interface Craft** — Creative technology

*Specific languages, frameworks, tools, and proficiency levels will be listed after verification; no unverified technology badges or statistics are included.*

## Verified Achievements & Certifications

Achievement and certification entries are intentionally omitted until supporting evidence is available. In particular, education/CGPA and competition placements should be included only when the supplied resume or official evidence confirms them.

## GitHub Activity

No contribution heatmap or statistics card is embedded yet: the correct GitHub username and a reliable data source must be confirmed first. This avoids showing another person's activity or decorative numbers as real metrics.

---

<p align="center">
  <img src="assets/sushmita-footer.svg" alt="Burgundy abstract technical footer" width="100%" />
</p>
